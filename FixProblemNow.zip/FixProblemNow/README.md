# Fix Problem Now

A complete, production-ready technology troubleshooting website built with Next.js 15, TypeScript, and Tailwind CSS.

## Overview

Fix Problem Now (https://fixproblemnow.com/) helps people understand and solve common technology problems without unnecessary technical jargon. It provides practical, step-by-step troubleshooting guides for computers, phones, WiFi, printers, software, Smart TVs and more.

## Features

- **Responsive Design** - Mobile-first, works on all devices
- **SEO Optimized** - Meta tags, structured data, sitemap, robots.txt
- **Fast Performance** - Static site generation for optimal speed
- **Comprehensive Categories** - Computer, Phone, WiFi/Internet, Printer, Software, Smart TV problems
- **Practical Guides** - Step-by-step troubleshooting with safety warnings
- **Search Functionality** - Find guides quickly
- **Legal Pages** - Privacy Policy, Terms of Use, Disclaimer, Editorial Policy

## Tech Stack

- **Framework:** Next.js 15 with App Router
- **Language:** TypeScript
- **Styling:** Tailwind CSS
- **Content:** Static content in TSX/Markdown
- **Build:** Static export

## Getting Started

### Prerequisites

- Node.js 18+ and npm

### Installation

1. Clone the repository
```bash
git clone <repository-url>
cd fix-problem-now
```

2. Install dependencies
```bash
npm install
```

3. Run development server
```bash
npm run dev
```

4. Open [http://localhost:3000](http://localhost:3000) in your browser

## Build and Deploy

### Production Build

```bash
npm run build
```

This generates a static site in the `out/` directory.

### Deployment

The site uses static export, so it can be deployed to any static hosting provider:
- Netlify
- Vercel
- GitHub Pages
- Cloudflare Pages
- AWS S3 + CloudFront

For deployment to fixproblemnow.com:
1. Build the site with `npm run build`
2. Upload the contents of `out/` directory to your web server
3. Configure DNS to point to your hosting provider
4. Enable HTTPS

## Environment Variables

For the contact form (if enhanced), you may need:
```env
EMAIL_SERVICE_API_KEY=
CONTACT_EMAIL=
```

Currently the contact form is for demonstration - configure your preferred email service as needed.

## Content Management

Articles are organized under `app/routes/[category]/[slug]/page.tsx`. To add new articles:

1. Create a new directory under the appropriate category
2. Add a `page.tsx` with metadata and content
3. Update the category page to include the new article
4. Update the sitemap and search functionality

## SEO

- Each page has unique title and meta description
- Canonical URLs are set
- Sitemap generated at `/sitemap.xml`
- Robots.txt at `/robots.txt`
- Semantic HTML structure

## License

© 2026 Fix Problem Now. All rights reserved.
