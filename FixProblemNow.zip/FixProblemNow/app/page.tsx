import Link from 'next/link'

const categories = [
  { name: 'Computer Problems', href: '/computer-problems/', icon: '💻', desc: 'Fix slow PCs, crashes, blue screens' },
  { name: 'Phone Problems', href: '/phone-problems/', icon: '📱', desc: 'Charging, battery, app issues' },
  { name: 'WiFi & Internet', href: '/wifi-internet-problems/', icon: '📶', desc: 'Connection drops, slow internet' },
  { name: 'Printer Problems', href: '/printer-problems/', icon: '🖨️', desc: 'Offline, not printing, paper jams' },
  { name: 'Software Problems', href: '/software-problems/', icon: '⚙️', desc: 'Crashes, installation, updates' },
  { name: 'Smart TV Problems', href: '/smart-tv-problems/', icon: '📺', desc: 'Apps, connectivity, display issues' },
]

const popularGuides = [
  { title: 'Wi-Fi Connected but No Internet? 10 Fixes to Try', href: '/wifi-internet-problems/wifi-connected-no-internet/', category: 'WiFi & Internet' },
  { title: 'Laptop Not Charging - Troubleshooting Guide', href: '/computer-problems/laptop-not-charging/', category: 'Computer Problems' },
  { title: 'Printer Showing Offline - How to Fix', href: '/printer-problems/printer-showing-offline/', category: 'Printer Problems' },
  { title: 'Smart TV Not Connecting to Wi-Fi', href: '/smart-tv-problems/tv-not-connecting-to-wifi/', category: 'Smart TV Problems' },
]

export default function Home() {
  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-50 to-white py-16 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-brand-navy mb-6 leading-tight">
            Fix Your Tech Problems with Simple, Step-by-Step Guides
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            From slow computers and phone charging issues to Wi-Fi connection failures, printer errors, and Smart TV problems, find practical troubleshooting steps that help you get your devices working again.
          </p>
          
          <div className="max-w-2xl mx-auto mb-6">
            <form action="/search/" method="get" className="flex flex-col sm:flex-row gap-3">
              <input
                type="text"
                name="q"
                placeholder="What problem are you facing?"
                className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary focus:border-transparent"
                aria-label="Search for problems"
              />
              <button
                type="submit"
                className="px-6 py-3 bg-brand-primary text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
              >
                Search
              </button>
            </form>
          </div>
        </div>
      </section>

      {/* Browse by Category */}
      <section className="py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl font-bold text-brand-navy text-center mb-12">Browse by Problem</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {categories.map((category) => (
              <Link
                key={category.href}
                href={category.href}
                className="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-lg hover:border-brand-primary transition-all duration-200 group"
              >
                <div className="text-3xl mb-3">{category.icon}</div>
                <h3 className="text-xl font-semibold text-brand-navy mb-2 group-hover:text-brand-primary transition-colors">
                  {category.name}
                </h3>
                <p className="text-gray-600">{category.desc}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Popular Guides */}
      <section className="py-16 px-4 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl font-bold text-brand-navy text-center mb-12">Popular Troubleshooting Guides</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {popularGuides.map((guide, index) => (
              <Link
                key={index}
                href={guide.href}
                className="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-lg transition-all duration-200 group"
              >
                <span className="inline-block px-3 py-1 bg-blue-100 text-brand-primary text-sm rounded-full mb-3">
                  {guide.category}
                </span>
                <h3 className="text-lg font-semibold text-brand-navy mb-2 group-hover:text-brand-primary transition-colors">
                  {guide.title}
                </h3>
                <div className="text-brand-primary font-medium group-hover:underline">
                  Read Guide →
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-brand-navy text-center mb-12">How Fix Problem Now Works</h2>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
            {[
              { step: '1', title: 'Search', desc: 'Find your problem' },
              { step: '2', title: 'Open Guide', desc: 'Read the solution' },
              { step: '3', title: 'Follow Steps', desc: 'Do in order' },
              { step: '4', title: 'Test Result', desc: 'Check if fixed' },
              { step: '5', title: 'Try Alternatives', desc: 'If needed' },
            ].map((item) => (
              <div key={item.step} className="text-center">
                <div className="w-12 h-12 bg-brand-primary text-white rounded-full flex items-center justify-center text-xl font-bold mx-auto mb-3">
                  {item.step}
                </div>
                <h3 className="font-semibold text-brand-navy mb-1">{item.title}</h3>
                <p className="text-sm text-gray-600">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}
