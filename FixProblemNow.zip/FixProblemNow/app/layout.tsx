import type { Metadata } from 'next'
import './globals.css'
import Header from './components/Header'
import Footer from './components/Footer'

export const metadata: Metadata = {
  title: 'Fix Problem Now - Simple Solutions to Everyday Technology Problems',
  description: 'Find practical, step-by-step troubleshooting guides for computers, phones, WiFi, printers, software, Smart TVs and more. Solve tech problems quickly and safely.',
  keywords: 'tech support, troubleshooting, fix computer, phone repair, wifi problems, printer issues',
  metadataBase: new URL('https://fixproblemnow.com'),
  alternates: {
    canonical: '/',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-white text-slate-900">
        <Header />
        <main className="min-h-screen">
          {children}
        </main>
        <Footer />
      </body>
    </html>
  )
}
