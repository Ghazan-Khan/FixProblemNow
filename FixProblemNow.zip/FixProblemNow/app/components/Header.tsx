'use client'

import Link from 'next/link'
import { useState } from 'react'

const categories = [
  { name: 'Computer Problems', href: '/computer-problems/' },
  { name: 'Phone Problems', href: '/phone-problems/' },
  { name: 'WiFi & Internet', href: '/wifi-internet-problems/' },
  { name: 'Printer Problems', href: '/printer-problems/' },
  { name: 'Software Problems', href: '/software-problems/' },
  { name: 'Smart TV Problems', href: '/smart-tv-problems/' },
]

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-50 shadow-sm">
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <Link href="/" className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-brand-primary rounded-lg flex items-center justify-center">
                <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                </svg>
              </div>
              <span className="text-xl font-bold text-brand-navy">Fix Problem Now</span>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center space-x-6">
            <Link href="/" className="text-gray-700 hover:text-brand-primary transition-colors">Home</Link>
            {categories.map((cat) => (
              <Link key={cat.href} href={cat.href} className="text-gray-700 hover:text-brand-primary transition-colors text-sm">
                {cat.name}
              </Link>
            ))}
            <Link href="/search/" className="text-gray-700 hover:text-brand-primary transition-colors">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </Link>
          </div>

          {/* Mobile menu button */}
          <div className="lg:hidden">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-gray-700 hover:text-brand-primary focus:outline-none focus:ring-2 focus:ring-brand-primary rounded-md p-2"
              aria-label="Toggle menu"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                {isMenuOpen ? (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                ) : (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                )}
              </svg>
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="lg:hidden border-t border-gray-200 py-4">
            <div className="flex flex-col space-y-3">
              <Link href="/" className="text-gray-700 hover:text-brand-primary transition-colors">Home</Link>
              {categories.map((cat) => (
                <Link key={cat.href} href={cat.href} className="text-gray-700 hover:text-brand-primary transition-colors">
                  {cat.name}
                </Link>
              ))}
              <Link href="/search/" className="text-gray-700 hover:text-brand-primary transition-colors">Search</Link>
            </div>
          </div>
        )}
      </nav>
    </header>
  )
}
