import Link from 'next/link'

export default function Footer() {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="bg-gray-50 border-t border-gray-200 mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-8 h-8 bg-brand-primary rounded-lg flex items-center justify-center">
                <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                </svg>
              </div>
              <span className="text-xl font-bold text-brand-navy">Fix Problem Now</span>
            </div>
            <p className="text-gray-600 mb-4 max-w-md">
              Simple solutions to everyday technology problems. Find step-by-step troubleshooting guides for all your devices.
            </p>
          </div>

          <div>
            <h3 className="font-semibold text-brand-navy mb-4">Company</h3>
            <ul className="space-y-2">
              <li><Link href="/about-us/" className="text-gray-600 hover:text-brand-primary transition-colors">About Us</Link></li>
              <li><Link href="/contact-us/" className="text-gray-600 hover:text-brand-primary transition-colors">Contact Us</Link></li>
              <li><Link href="/editorial-policy/" className="text-gray-600 hover:text-brand-primary transition-colors">Editorial Policy</Link></li>
              <li><Link href="/how-we-test-solutions/" className="text-gray-600 hover:text-brand-primary transition-colors">How We Test Solutions</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-brand-navy mb-4">Legal</h3>
            <ul className="space-y-2">
              <li><Link href="/privacy-policy/" className="text-gray-600 hover:text-brand-primary transition-colors">Privacy Policy</Link></li>
              <li><Link href="/terms-of-use/" className="text-gray-600 hover:text-brand-primary transition-colors">Terms of Use</Link></li>
              <li><Link href="/disclaimer/" className="text-gray-600 hover:text-brand-primary transition-colors">Disclaimer</Link></li>
              <li><Link href="/sitemap/" className="text-gray-600 hover:text-brand-primary transition-colors">Sitemap</Link></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-200 mt-8 pt-8 text-center">
          <p className="text-gray-600">
            © {currentYear} Fix Problem Now. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  )
}
