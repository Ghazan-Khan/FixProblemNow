import Link from 'next/link'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Disclaimer - Fix Problem Now',
  description: 'Disclaimer for Fix Problem Now - important information about our troubleshooting advice.',
  alternates: {
    canonical: '/disclaimer/',
  },
}

export default function DisclaimerPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <nav className="text-sm text-gray-600 mb-6">
        <Link href="/" className="hover:text-brand-primary">Home</Link>
        <span className="mx-2">/</span>
        <span className="text-brand-navy">Disclaimer</span>
      </nav>

      <h1 className="text-4xl font-bold text-brand-navy mb-6">Disclaimer</h1>

      <div className="prose prose-lg max-w-none space-y-6">
        <section>
          <h2 className="text-2xl font-bold text-brand-navy mb-3">General Information</h2>
          <p className="text-gray-700">
            The information provided on Fix Problem Now is for general informational and educational purposes only. 
            It is not intended as professional technical support or advice.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-brand-navy mb-3">No Warranty</h2>
          <p className="text-gray-700">
            We make no representations or warranties of any kind, express or implied, about the completeness, 
            accuracy, reliability, suitability or availability of the information.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-brand-navy mb-3">Use at Your Own Risk</h2>
          <p className="text-gray-700">
            Any reliance you place on such information is strictly at your own risk. We will not be liable for 
            any loss or damage including without limitation, indirect or consequential loss or damage.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-brand-navy mb-3">Third-Party Products</h2>
          <p className="text-gray-700">
            We are not affiliated with Microsoft, Apple, Google, Samsung, HP, Canon, or any other manufacturer 
            unless explicitly stated. All product names are trademarks of their respective owners.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-brand-navy mb-3">Data Backup</h2>
          <p className="text-gray-700">
            Always back up important data before performing any troubleshooting steps that may result in data loss.
          </p>
        </section>
      </div>
    </div>
  )
}
