import Link from 'next/link'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'How We Test Solutions - Fix Problem Now',
  description: 'Learn how we research and validate troubleshooting solutions before publishing them.',
  alternates: {
    canonical: '/how-we-test-solutions/',
  },
}

export default function HowWeTestSolutionsPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <nav className="text-sm text-gray-600 mb-6">
        <Link href="/" className="hover:text-brand-primary">Home</Link>
        <span className="mx-2">/</span>
        <span className="text-brand-navy">How We Test Solutions</span>
      </nav>

      <h1 className="text-4xl font-bold text-brand-navy mb-6">How We Test Solutions</h1>

      <div className="prose prose-lg max-w-none space-y-6">
        <section>
          <h2 className="text-2xl font-bold text-brand-navy mb-3">Our Testing Process</h2>
          <p className="text-gray-700 mb-4">
            We follow a systematic approach to ensure our troubleshooting guides are practical and safe:
          </p>
          <ol className="list-decimal pl-6 space-y-3 text-gray-700">
            <li><strong>Research:</strong> We study the problem using official documentation and common troubleshooting practices</li>
            <li><strong>Identify Solutions:</strong> We compile safe, tested solutions in order of simplicity</li>
            <li><strong>Validate Steps:</strong> We verify instructions are clear and follow standard procedures</li>
            <li><strong>Safety Review:</strong> We add appropriate warnings for potentially risky operations</li>
            <li><strong>Review:</strong> Content is reviewed for clarity and accuracy before publication</li>
          </ol>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-brand-navy mb-3">Principles</h2>
          <ul className="list-disc pl-6 space-y-2 text-gray-700">
            <li><strong>Safety First:</strong> We prioritize non-destructive solutions</li>
            <li><strong>Start Simple:</strong> Easiest fixes come first</li>
            <li><strong>Be Realistic:</strong> We mention when professional help is needed</li>
            <li><strong>Stay Current:</strong> We update guides as needed</li>
          </ul>
        </section>
      </div>
    </div>
  )
}
