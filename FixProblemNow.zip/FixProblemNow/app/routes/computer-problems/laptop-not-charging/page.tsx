import Link from 'next/link'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Laptop Not Charging - Troubleshooting Guide | Fix Problem Now',
  description: 'Fix laptop charging problems step by step. Check charger, battery, ports and settings to resolve charging issues.',
  keywords: 'laptop not charging, laptop battery not charging, charger not working',
  alternates: {
    canonical: '/computer-problems/laptop-not-charging/',
  },
}

export default function LaptopNotChargingPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <nav className="text-sm text-gray-600 mb-6">
        <Link href="/" className="hover:text-brand-primary">Home</Link>
        <span className="mx-2">/</span>
        <Link href="/computer-problems/" className="hover:text-brand-primary">Computer Problems</Link>
        <span className="mx-2">/</span>
        <span className="text-brand-navy">Laptop Not Charging</span>
      </nav>

      <article>
        <header className="mb-8">
          <span className="inline-block px-3 py-1 bg-blue-100 text-brand-primary text-sm rounded-full mb-4">
            Computer Problems
          </span>
          <h1 className="text-4xl font-bold text-brand-navy mb-4">
            Laptop Not Charging - Troubleshooting Guide
          </h1>
          <p className="text-lg text-gray-600">
            If your laptop won't charge or stops charging, follow these safe troubleshooting steps to identify and fix the issue.
          </p>
        </header>

        <section className="mb-8">
          <h2 className="text-2xl font-bold text-brand-navy mb-4">Quick Checks (Do First)</h2>
          <div className="bg-blue-50 border-l-4 border-brand-primary p-4 rounded-r-lg">
            <ol className="list-decimal pl-6 space-y-1 text-brand-navy">
              <li>Check power outlet with another device</li>
              <li>Inspect charger cable and adapter for damage</li>
              <li>Try different outlet</li>
              <li>Remove battery (if removable) and test with AC only</li>
            </ol>
          </div>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-bold text-brand-navy mb-4">Step-by-Step Fixes</h2>
          
          <div className="space-y-6">
            <div className="border border-gray-200 rounded-lg p-6">
              <h3 className="text-xl font-semibold text-brand-navy mb-3">1. Hard Reset Your Laptop</h3>
              <ol className="list-decimal pl-6 space-y-2 text-gray-700">
                <li>Shut down your laptop completely</li>
                <li>Unplug the charger</li>
                <li>If battery is removable, remove it</li>
                <li>Hold the power button for 60 seconds</li>
                <li>Reinsert battery (if removed), plug in charger, turn on</li>
              </ol>
            </div>

            <div className="border border-gray-200 rounded-lg p-6">
              <h3 className="text-xl font-semibold text-brand-navy mb-3">2. Check the Charging Port</h3>
              <ul className="list-disc pl-6 space-y-2 text-gray-700">
                <li>Look for dust, lint, or debris in the charging port</li>
                <li>Use a flashlight to inspect carefully</li>
                <li>Gently clean with compressed air or a dry toothpick (very carefully)</li>
                <li>Check for bent pins or damage</li>
              </ul>
            </div>

            <div className="border border-gray-200 rounded-lg p-6">
              <h3 className="text-xl font-semibold text-brand-navy mb-3">3. Update Battery Drivers (Windows)</h3>
              <ol className="list-decimal pl-6 space-y-2 text-gray-700">
                <li>Open Device Manager (Win + X &gt; Device Manager)</li>
                <li>Expand "Batteries"</li>
                <li>Right-click "Microsoft ACPI-Compliant Control Method Battery"</li>
                <li>Select "Uninstall device"</li>
                <li>Restart your laptop (Windows will reinstall automatically)</li>
              </ol>
            </div>

            <div className="border border-gray-200 rounded-lg p-6">
              <h3 className="text-xl font-semibold text-brand-navy mb-3">4. Test with Another Charger</h3>
              <p className="text-gray-700">
                If possible, try a compatible charger from the same manufacturer or a known working charger with correct voltage/wattage.
              </p>
            </div>
          </div>
        </section>

        <section className="mb-8 bg-red-50 border-l-4 border-red-400 p-4 rounded-r-lg">
          <h2 className="text-lg font-semibold text-red-800 mb-2">⚠️ Safety Warnings</h2>
          <ul className="list-disc pl-6 space-y-1 text-red-700">
            <li>Don't use damaged chargers or cables</li>
            <li>If battery is swollen, stop using immediately and seek professional help</li>
            <li>Don't attempt to open or repair battery yourself</li>
          </ul>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-bold text-brand-navy mb-4">When to Seek Professional Help</h2>
          <ul className="list-disc pl-6 space-y-2 text-gray-700">
            <li>Battery is physically swollen or damaged</li>
            <li>Charger port is loose or damaged</li>
            <li>Charging circuit issue suspected</li>
            <li>All troubleshooting steps fail</li>
          </ul>
        </section>
      </article>
    </div>
  )
}
