import Link from 'next/link'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Computer Problems - Troubleshooting Guides | Fix Problem Now',
  description: 'Fix computer crashes, blue screens, slow performance, boot issues, overheating and hardware problems with step-by-step guides.',
  keywords: 'computer problems, pc issues, laptop problems, blue screen, computer slow',
  alternates: {
    canonical: '/computer-problems/',
  },
}

export default function ComputerProblemsPage() {
  const articles = [
    { title: 'Laptop Not Charging - Troubleshooting Guide', href: '/computer-problems/laptop-not-charging/', desc: 'Fix charging issues on your laptop' },
    { title: 'Computer Won\'t Turn On - How to Fix', href: '/computer-problems/computer-wont-turn-on/', desc: 'Diagnose power and boot issues' },
    { title: 'How to Fix a Slow Computer', href: '/computer-problems/slow-computer-fix/', desc: 'Speed up your PC performance' },
    { title: 'Windows Blue Screen Errors - Troubleshooting', href: '/computer-problems/blue-screen-fix/', desc: 'Fix BSOD errors safely' },
  ]

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <nav className="text-sm text-gray-600 mb-6">
        <Link href="/" className="hover:text-brand-primary">Home</Link>
        <span className="mx-2">/</span>
        <span className="text-brand-navy">Computer Problems</span>
      </nav>

      <header className="mb-8">
        <h1 className="text-4xl font-bold text-brand-navy mb-4">Computer Problems</h1>
        <p className="text-lg text-gray-600">
          Troubleshoot PC and laptop issues including startup problems, performance issues, hardware failures, and software errors.
        </p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {articles.map((article, index) => (
          <Link
            key={index}
            href={article.href}
            className="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-lg hover:border-brand-primary transition-all duration-200 group"
          >
            <h2 className="text-xl font-semibold text-brand-navy mb-2 group-hover:text-brand-primary transition-colors">
              {article.title}
            </h2>
            <p className="text-gray-600 mb-3">{article.desc}</p>
            <div className="text-brand-primary font-medium group-hover:underline">
              Read Guide →
            </div>
          </Link>
        ))}
      </div>
    </div>
  )
}
