import Link from 'next/link'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Editorial Policy - Fix Problem Now',
  description: 'Our editorial policy on content creation, fact-checking, and maintaining accuracy in troubleshooting guides.',
  alternates: {
    canonical: '/editorial-policy/',
  },
}

export default function EditorialPolicyPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <nav className="text-sm text-gray-600 mb-6">
        <Link href="/" className="hover:text-brand-primary">Home</Link>
        <span className="mx-2">/</span>
        <span className="text-brand-navy">Editorial Policy</span>
      </nav>

      <h1 className="text-4xl font-bold text-brand-navy mb-6">Editorial Policy</h1>

      <div className="prose prose-lg max-w-none space-y-6">
        <section>
          <h2 className="text-2xl font-bold text-brand-navy mb-3">Our Commitment</h2>
          <p className="text-gray-700">
            We are committed to providing accurate, helpful, and safe troubleshooting guidance. 
            All content is created with user safety and practical usefulness as top priorities.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-brand-navy mb-3">Content Creation</h2>
          <ul className="list-disc pl-6 space-y-2 text-gray-700">
            <li>Guides are written in clear, beginner-friendly language</li>
            <li>Steps are listed in order of simplicity and safety</li>
            <li>Safety warnings are included where necessary</li>
            <li>Alternative solutions are provided when applicable</li>
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-brand-navy mb-3">Accuracy and Updates</h2>
          <ul className="list-disc pl-6 space-y-2 text-gray-700">
            <li>Content is based on established troubleshooting practices</li>
            <li>We reference official documentation where possible</li>
            <li>Guides are updated as technology changes</li>
            <li>Errors are corrected promptly when reported</li>
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-brand-navy mb-3">Independence</h2>
          <p className="text-gray-700">
            Fix Problem Now is an independent resource. We are not affiliated with any device manufacturer 
            or software company unless explicitly disclosed.
          </p>
        </section>
      </div>
    </div>
  )
}
