import Link from 'next/link'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Smart TV Not Connecting to Wi-Fi - How to Fix | Fix Problem Now',
  description: 'Fix Smart TV WiFi connection issues. Troubleshoot network settings, router, and TV problems step by step.',
  keywords: 'smart tv wifi not connecting, tv won\'t connect to wifi, samsung tv wifi',
  alternates: {
    canonical: '/smart-tv-problems/tv-not-connecting-to-wifi/',
  },
}

export default function TVNotConnectingWifiPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <nav className="text-sm text-gray-600 mb-6">
        <Link href="/" className="hover:text-brand-primary">Home</Link>
        <span className="mx-2">/</span>
        <Link href="/smart-tv-problems/" className="hover:text-brand-primary">Smart TV Problems</Link>
        <span className="mx-2">/</span>
        <span className="text-brand-navy">TV Not Connecting to Wi-Fi</span>
      </nav>

      <article>
        <header className="mb-8">
          <span className="inline-block px-3 py-1 bg-blue-100 text-brand-primary text-sm rounded-full mb-4">
            Smart TV Problems
          </span>
          <h1 className="text-4xl font-bold text-brand-navy mb-4">
            Smart TV Not Connecting to Wi-Fi - How to Fix
          </h1>
          <p className="text-lg text-gray-600">
            If your Smart TV won't connect to Wi-Fi or keeps failing to connect, try these troubleshooting steps.
          </p>
        </header>

        <section className="mb-8">
          <h2 className="text-2xl font-bold text-brand-navy mb-4">Quick Fix</h2>
          <div className="bg-blue-50 border-l-4 border-brand-primary p-4 rounded-r-lg">
            <ol className="list-decimal pl-6 space-y-1 text-brand-navy">
              <li>Restart your TV (power off for 60 seconds)</li>
              <li>Restart your router</li>
              <li>Move TV closer to router or use ethernet cable</li>
            </ol>
          </div>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-bold text-brand-navy mb-4">Step-by-Step Solutions</h2>
          
          <div className="space-y-6">
            <div className="border border-gray-200 rounded-lg p-6">
              <h3 className="text-xl font-semibold text-brand-navy mb-3">1. Power Cycle Everything</h3>
              <ol className="list-decimal pl-6 space-y-2 text-gray-700">
                <li>Turn off TV and unplug from power for 60 seconds</li>
                <li>Unplug router and modem for 30 seconds</li>
                <li>Plug modem in first, wait 2 minutes</li>
                <li>Plug router in, wait 2 minutes</li>
                <li>Plug TV back in and try to connect</li>
              </ol>
            </div>

            <div className="border border-gray-200 rounded-lg p-6">
              <h3 className="text-xl font-semibold text-brand-navy mb-3">2. Check Network on TV</h3>
              <ol className="list-decimal pl-6 space-y-2 text-gray-700">
                <li>Go to TV Settings &gt; Network/Wi-Fi Settings</li>
                <li>Forget your network if previously connected</li>
                <li>Select your Wi-Fi network again</li>
                <li>Enter password carefully (check case sensitivity)</li>
              </ol>
            </div>

            <div className="border border-gray-200 rounded-lg p-6">
              <h3 className="text-xl font-semibold text-brand-navy mb-3">3. Use Ethernet Cable (Test)</h3>
              <p className="text-gray-700">
                Connect your TV directly to router with Ethernet cable. If it works wired but not wireless, it's a Wi-Fi signal issue.
              </p>
            </div>

            <div className="border border-gray-200 rounded-lg p-6">
              <h3 className="text-xl font-semibold text-brand-navy mb-3">4. Change Wi-Fi Band</h3>
              <ul className="list-disc pl-6 space-y-2 text-gray-700">
                <li>Try 2.4GHz band (better range, slower speeds)</li>
                <li>Some older TVs don't support 5GHz</li>
                <li>If router has both, try connecting to 2.4GHz</li>
              </ul>
            </div>

            <div className="border border-gray-200 rounded-lg p-6">
              <h3 className="text-xl font-semibold text-brand-navy mb-3">5. Reset Network Settings</h3>
              <p className="text-gray-700">
                Look for "Reset Network Settings" in your TV's Network settings. This will clear all saved networks.
              </p>
            </div>
          </div>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-bold text-brand-navy mb-4">Additional Tips</h2>
          <ul className="list-disc pl-6 space-y-2 text-gray-700">
            <li><strong>Distance:</strong> Keep TV within reasonable range of router</li>
            <li><strong>Interference:</strong> Avoid placing router near microwaves or thick walls</li>
            <li><strong>Router settings:</strong> Try disabling MAC filtering temporarily</li>
            <li><strong>Update TV:</strong> Check for firmware updates</li>
            <li><strong>Use mobile hotspot:</strong> Test with phone hotspot to isolate issue</li>
          </ul>
        </section>
      </article>
    </div>
  )
}
