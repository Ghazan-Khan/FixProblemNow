import Link from 'next/link'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Smart TV Problems - Troubleshooting Guides | Fix Problem Now',
  description: 'Fix Smart TV WiFi issues, app problems, streaming issues, no sound, no picture, remote problems with step-by-step guides.',
  keywords: 'smart tv problems, tv wifi issues, netflix not working, tv apps',
  alternates: {
    canonical: '/smart-tv-problems/',
  },
}

export default function SmartTVProblemsPage() {
  const articles = [
    { title: 'Smart TV Not Connecting to Wi-Fi', href: '/smart-tv-problems/tv-not-connecting-to-wifi/', desc: 'Reconnect your Smart TV to network' },
    { title: 'Smart TV Apps Not Working', href: '/smart-tv-problems/tv-apps-not-working/', desc: 'Fix crashing or loading apps' },
    { title: 'TV Has No Sound - Troubleshooting Guide', href: '/smart-tv-problems/tv-no-sound/', desc: 'Fix audio issues' },
    { title: 'Smart TV Remote Not Working', href: '/smart-tv-problems/tv-remote-not-working/', desc: 'Fix remote control problems' },
  ]

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <nav className="text-sm text-gray-600 mb-6">
        <Link href="/" className="hover:text-brand-primary">Home</Link>
        <span className="mx-2">/</span>
        <span className="text-brand-navy">Smart TV Problems</span>
      </nav>

      <header className="mb-8">
        <h1 className="text-4xl font-bold text-brand-navy mb-4">Smart TV Problems</h1>
        <p className="text-lg text-gray-600">
          Troubleshoot Smart TV connectivity, apps, streaming, display, audio, and remote control issues.
        </p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {articles.map((article, index) => (
          <Link
            key={index}
            href={article.href}
            className="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-lg hover:border-brand-primary transition-all duration-200 group"
          >
            <h2 className="text-xl font-semibold text-brand-navy mb-2 group-hover:text-brand-primary transition-colors">
              {article.title}
            </h2>
            <p className="text-gray-600 mb-3">{article.desc}</p>
            <div className="text-brand-primary font-medium group-hover:underline">
              Read Guide →
            </div>
          </Link>
        ))}
      </div>
    </div>
  )
}
