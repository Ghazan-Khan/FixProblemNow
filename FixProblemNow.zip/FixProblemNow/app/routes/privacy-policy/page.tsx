import Link from 'next/link'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Privacy Policy - Fix Problem Now',
  description: 'Privacy Policy for Fix Problem Now. Learn how we collect, use, and protect your information.',
  alternates: {
    canonical: '/privacy-policy/',
  },
}

export default function PrivacyPolicyPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <nav className="text-sm text-gray-600 mb-6">
        <Link href="/" className="hover:text-brand-primary">Home</Link>
        <span className="mx-2">/</span>
        <span className="text-brand-navy">Privacy Policy</span>
      </nav>

      <h1 className="text-4xl font-bold text-brand-navy mb-6">Privacy Policy</h1>
      <p className="text-gray-600 mb-6">Last updated: October 21, 2026</p>

      <div className="prose prose-lg max-w-none space-y-6">
        <section>
          <h2 className="text-2xl font-bold text-brand-navy mb-3">Information We Collect</h2>
          <p className="text-gray-700 mb-3">
            Fix Problem Now is a static website. We may collect:
          </p>
          <ul className="list-disc pl-6 space-y-2 text-gray-700">
            <li>Information you provide through our contact form (name, email, message)</li>
            <li>Usage data through analytics (if enabled)</li>
            <li>Search queries through our search functionality</li>
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-brand-navy mb-3">How We Use Information</h2>
          <p className="text-gray-700">
            We use the information to respond to inquiries, improve our content, and provide better troubleshooting guides.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-brand-navy mb-3">Cookies</h2>
          <p className="text-gray-700">
            Our website may use cookies for basic functionality and analytics. You can disable cookies in your browser settings.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-brand-navy mb-3">Contact</h2>
          <p className="text-gray-700">
            For privacy-related questions, please use our <Link href="/contact-us/" className="text-brand-primary hover:underline">Contact Us</Link> page.
          </p>
        </section>
      </div>
    </div>
  )
}
