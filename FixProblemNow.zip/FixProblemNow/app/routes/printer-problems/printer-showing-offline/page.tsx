import Link from 'next/link'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Printer Showing Offline - How to Fix | Fix Problem Now',
  description: 'Fix printer showing offline on Windows, Mac, or network. Step-by-step guide to bring your printer back online.',
  keywords: 'printer offline, printer showing offline, bring printer online',
  alternates: {
    canonical: '/printer-problems/printer-showing-offline/',
  },
}

export default function PrinterOfflinePage() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <nav className="text-sm text-gray-600 mb-6">
        <Link href="/" className="hover:text-brand-primary">Home</Link>
        <span className="mx-2">/</span>
        <Link href="/printer-problems/" className="hover:text-brand-primary">Printer Problems</Link>
        <span className="mx-2">/</span>
        <span className="text-brand-navy">Printer Showing Offline</span>
      </nav>

      <article>
        <header className="mb-8">
          <span className="inline-block px-3 py-1 bg-blue-100 text-brand-primary text-sm rounded-full mb-4">
            Printer Problems
          </span>
          <h1 className="text-4xl font-bold text-brand-navy mb-4">
            Printer Showing Offline - How to Fix
          </h1>
          <p className="text-lg text-gray-600">
            If your printer appears as "Offline" even when powered on and connected, try these solutions to bring it back online.
          </p>
        </header>

        <section className="mb-8">
          <h2 className="text-2xl font-bold text-brand-navy mb-4">Quick Fix (Try First)</h2>
          <div className="bg-blue-50 border-l-4 border-brand-primary p-4 rounded-r-lg">
            <ol className="list-decimal pl-6 space-y-1 text-brand-navy">
              <li>Turn printer off and on</li>
              <li>Check USB cable or Wi-Fi connection</li>
              <li>Restart your computer</li>
              <li>Set printer as default</li>
            </ol>
          </div>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-bold text-brand-navy mb-4">Step-by-Step Solutions</h2>
          
          <div className="space-y-6">
            <div className="border border-gray-200 rounded-lg p-6">
              <h3 className="text-xl font-semibold text-brand-navy mb-3">1. Check Basic Connections</h3>
              <ul className="list-disc pl-6 space-y-2 text-gray-700">
                <li><strong>USB:</strong> Ensure cable is firmly connected to both printer and computer</li>
                <li><strong>Wi-Fi:</strong> Make sure printer and computer are on the same network</li>
                <li><strong>Power:</strong> Verify printer is powered on and has no error lights</li>
              </ul>
            </div>

            <div className="border border-gray-200 rounded-lg p-6">
              <h3 className="text-xl font-semibold text-brand-navy mb-3">2. Set Printer Online (Windows)</h3>
              <ol className="list-decimal pl-6 space-y-2 text-gray-700">
                <li>Press Win + R, type <code className="bg-gray-100 px-1 rounded">control printers</code> and Enter</li>
                <li>Right-click your printer and select "See what's printing"</li>
                <li>Click "Printer" in the menu bar</li>
                <li>Uncheck "Use Printer Offline" if it's checked</li>
                <li>Also ensure "Pause Printing" is unchecked</li>
              </ol>
            </div>

            <div className="border border-gray-200 rounded-lg p-6">
              <h3 className="text-xl font-semibold text-brand-navy mb-3">3. Set as Default Printer (Windows)</h3>
              <ol className="list-decimal pl-6 space-y-2 text-gray-700">
                <li>Go to Control Panel &gt; Devices and Printers</li>
                <li>Right-click your printer</li>
                <li>Select "Set as default printer"</li>
                <li>Windows will manage default printer - disable if causing issues</li>
              </ol>
            </div>

            <div className="border border-gray-200 rounded-lg p-6">
              <h3 className="text-xl font-semibold text-brand-navy mb-3">4. Restart Print Spooler (Windows)</h3>
              <ol className="list-decimal pl-6 space-y-2 text-gray-700">
                <li>Press Win + R, type <code className="bg-gray-100 px-1 rounded">services.msc</code></li>
                <li>Find "Print Spooler" in the list</li>
                <li>Right-click it and select "Restart"</li>
                <li>Try printing again</li>
              </ol>
            </div>

            <div className="border border-gray-200 rounded-lg p-6">
              <h3 className="text-xl font-semibold text-brand-navy mb-3">5. For Mac Users</h3>
              <ol className="list-decimal pl-6 space-y-2 text-gray-700">
                <li>Go to System Preferences &gt; Printers &amp; Scanners</li>
                <li>Select your printer</li>
                <li>Click "Open Print Queue"</li>
                <li>Click the resume button if paused</li>
                <li>If offline, delete and re-add the printer</li>
              </ol>
            </div>
          </div>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-bold text-brand-navy mb-4">If Still Offline</h2>
          <ul className="list-disc pl-6 space-y-2 text-gray-700">
            <li><strong>Update drivers:</strong> Download latest from manufacturer's website</li>
            <li><strong>Reinstall printer:</strong> Remove and add it again</li>
            <li><strong>Network issues:</strong> Restart router if using Wi-Fi</li>
            <li><strong>Use manufacturer's app:</strong> Many printers have dedicated apps for troubleshooting</li>
          </ul>
        </section>
      </article>
    </div>
  )
}
