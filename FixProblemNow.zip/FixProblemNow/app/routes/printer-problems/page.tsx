import Link from 'next/link'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Printer Problems - Troubleshooting Guides | Fix Problem Now',
  description: 'Fix printer offline issues, not printing, paper jams, WiFi connection problems, driver issues with step-by-step guides.',
  keywords: 'printer problems, printer offline, printer not printing, printer wifi',
  alternates: {
    canonical: '/printer-problems/',
  },
}

export default function PrinterProblemsPage() {
  const articles = [
    { title: 'Printer Showing Offline - How to Fix', href: '/printer-problems/printer-showing-offline/', desc: 'Bring your printer back online' },
    { title: 'Printer Not Printing - Troubleshooting Guide', href: '/printer-problems/printer-not-printing/', desc: 'Fix printing failures' },
    { title: 'Printer Not Connecting to Wi-Fi', href: '/printer-problems/printer-not-connecting-wifi/', desc: 'Reconnect wireless printer' },
    { title: 'Printer Printing Blank Pages', href: '/printer-problems/printer-printing-blank-pages/', desc: 'Fix blank page printing issues' },
  ]

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <nav className="text-sm text-gray-600 mb-6">
        <Link href="/" className="hover:text-brand-primary">Home</Link>
        <span className="mx-2">/</span>
        <span className="text-brand-navy">Printer Problems</span>
      </nav>

      <header className="mb-8">
        <h1 className="text-4xl font-bold text-brand-navy mb-4">Printer Problems</h1>
        <p className="text-lg text-gray-600">
          Fix common printer issues including offline status, connectivity problems, print quality issues, and paper jams.
        </p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {articles.map((article, index) => (
          <Link
            key={index}
            href={article.href}
            className="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-lg hover:border-brand-primary transition-all duration-200 group"
          >
            <h2 className="text-xl font-semibold text-brand-navy mb-2 group-hover:text-brand-primary transition-colors">
              {article.title}
            </h2>
            <p className="text-gray-600 mb-3">{article.desc}</p>
            <div className="text-brand-primary font-medium group-hover:underline">
              Read Guide →
            </div>
          </Link>
        ))}
      </div>
    </div>
  )
}
