import Link from 'next/link'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Wi-Fi Connected but No Internet? 10 Fixes to Try | Fix Problem Now',
  description: 'Learn how to troubleshoot Wi-Fi connected without internet access. Fix DNS, router, and device issues with step-by-step solutions.',
  keywords: 'wifi connected no internet, wifi no internet access, connected to wifi but no internet',
  alternates: {
    canonical: '/wifi-internet-problems/wifi-connected-no-internet/',
  },
}

export default function WifiNoInternetPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <nav className="text-sm text-gray-600 mb-6">
        <Link href="/" className="hover:text-brand-primary">Home</Link>
        <span className="mx-2">/</span>
        <Link href="/wifi-internet-problems/" className="hover:text-brand-primary">WiFi & Internet Problems</Link>
        <span className="mx-2">/</span>
        <span className="text-brand-navy">Wi-Fi Connected but No Internet</span>
      </nav>

      <article>
        <header className="mb-8">
          <span className="inline-block px-3 py-1 bg-blue-100 text-brand-primary text-sm rounded-full mb-4">
            WiFi & Internet
          </span>
          <h1 className="text-4xl font-bold text-brand-navy mb-4">
            Wi-Fi Connected but No Internet? 10 Fixes to Try
          </h1>
          <p className="text-lg text-gray-600">
            If your device shows it's connected to Wi-Fi but you can't access the internet, try these step-by-step solutions in order.
          </p>
        </header>

        <section className="mb-8">
          <h2 className="text-2xl font-bold text-brand-navy mb-4">Quick Fix (Try This First)</h2>
          <div className="bg-blue-50 border-l-4 border-brand-primary p-4 rounded-r-lg">
            <p className="font-medium text-brand-navy">
              <strong>Quick Fix:</strong> Restart your router and modem. Unplug them for 30 seconds, then plug them back in. This fixes most connectivity issues.
            </p>
          </div>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-bold text-brand-navy mb-4">Symptoms</h2>
          <ul className="list-disc pl-6 space-y-2 text-gray-700">
            <li>Wi-Fi icon shows connected, but web pages won't load</li>
            <li>Apps can't connect to the internet</li>
            <li>Internet works on some devices but not others</li>
            <li>You see "No internet, secured" or similar messages</li>
          </ul>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-bold text-brand-navy mb-4">Step-by-Step Troubleshooting</h2>
          
          <div className="space-y-6">
            <div className="border border-gray-200 rounded-lg p-6">
              <h3 className="text-xl font-semibold text-brand-navy mb-3">1. Restart Your Router and Modem</h3>
              <ol className="list-decimal pl-6 space-y-2 text-gray-700">
                <li>Unplug your modem and router from power</li>
                <li>Wait 30 seconds</li>
                <li>Plug in the modem first, wait for lights to stabilize (1-2 minutes)</li>
                <li>Plug in the router, wait another 1-2 minutes</li>
                <li>Test your connection</li>
              </ol>
            </div>

            <div className="border border-gray-200 rounded-lg p-6">
              <h3 className="text-xl font-semibold text-brand-navy mb-3">2. Test on Another Device</h3>
              <p className="text-gray-700 mb-2">Check if the issue is with your device or the network:</p>
              <ul className="list-disc pl-6 space-y-1 text-gray-700">
                <li>Try connecting another phone, laptop, or tablet to the same Wi-Fi</li>
                <li>If other devices have internet, the problem is with your device</li>
                <li>If no devices have internet, the problem is with your network</li>
              </ul>
            </div>

            <div className="border border-gray-200 rounded-lg p-6">
              <h3 className="text-xl font-semibold text-brand-navy mb-3">3. Forget and Reconnect to Wi-Fi</h3>
              <p className="text-gray-700 mb-2"><strong>Windows:</strong></p>
              <ol className="list-decimal pl-6 space-y-1 text-gray-700 mb-3">
                <li>Go to Settings &gt; Network &amp; Internet &gt; Wi-Fi</li>
                <li>Click on your network &gt; Forget</li>
                <li>Reconnect by selecting the network and entering the password</li>
              </ol>
              <p className="text-gray-700 mb-2"><strong>Android/iOS:</strong></p>
              <ol className="list-decimal pl-6 space-y-1 text-gray-700">
                <li>Go to Wi-Fi settings</li>
                <li>Forget/remove your network</li>
                <li>Reconnect and enter password</li>
              </ol>
            </div>

            <div className="border border-gray-200 rounded-lg p-6">
              <h3 className="text-xl font-semibold text-brand-navy mb-3">4. Change DNS Settings</h3>
              <p className="text-gray-700 mb-2">Try using Google DNS (8.8.8.8, 8.8.4.4):</p>
              <ol className="list-decimal pl-6 space-y-1 text-gray-700">
                <li>Go to network settings for your connection</li>
                <li>Change DNS from automatic to manual</li>
                <li>Enter 8.8.8.8 as preferred and 8.8.4.4 as alternate</li>
                <li>Save and test connection</li>
              </ol>
            </div>

            <div className="border border-gray-200 rounded-lg p-6">
              <h3 className="text-xl font-semibold text-brand-navy mb-3">5. Run Network Troubleshooter</h3>
              <p className="text-gray-700 mb-2"><strong>Windows:</strong> Settings &gt; Update &amp; Security &gt; Troubleshoot &gt; Internet Connections</p>
              <p className="text-gray-700"><strong>macOS:</strong> Use Wireless Diagnostics (hold Option + click Wi-Fi icon)</p>
            </div>
          </div>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-bold text-brand-navy mb-4">If the Problem Persists</h2>
          <ul className="list-disc pl-6 space-y-2 text-gray-700">
            <li><strong>Contact your ISP:</strong> There might be an outage in your area</li>
            <li><strong>Update router firmware:</strong> Check your router manufacturer's website</li>
            <li><strong>Check cables:</strong> Ensure all Ethernet cables are securely connected</li>
            <li><strong>Reset router to factory defaults:</strong> Use as last resort (you'll need to reconfigure)</li>
          </ul>
        </section>

        <section className="mb-8 bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded-r-lg">
          <h2 className="text-lg font-semibold text-yellow-800 mb-2">⚠️ Safety Note</h2>
          <p className="text-yellow-700">
            When resetting your router, you'll lose all custom settings. Make sure you have your ISP login details and Wi-Fi credentials handy.
          </p>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-bold text-brand-navy mb-4">Related Guides</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Link href="/wifi-internet-problems/wifi-keeps-disconnecting/" className="p-4 border border-gray-200 rounded-lg hover:border-brand-primary hover:shadow-md transition-all">
              <h3 className="font-semibold text-brand-navy">Wi-Fi Keeps Disconnecting</h3>
            </Link>
            <Link href="/wifi-internet-problems/slow-internet-connection/" className="p-4 border border-gray-200 rounded-lg hover:border-brand-primary hover:shadow-md transition-all">
              <h3 className="font-semibold text-brand-navy">Slow Internet Connection</h3>
            </Link>
          </div>
        </section>
      </article>
    </div>
  )
}
