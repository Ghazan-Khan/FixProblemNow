import Link from 'next/link'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'WiFi & Internet Problems - Troubleshooting Guides | Fix Problem Now',
  description: 'Fix WiFi connection issues, slow internet, router problems, DNS errors and network connectivity issues with step-by-step guides.',
  keywords: 'wifi problems, internet issues, router not working, wifi keeps disconnecting',
  alternates: {
    canonical: '/wifi-internet-problems/',
  },
}

export default function WifiProblemsPage() {
  const articles = [
    { title: 'Wi-Fi Connected but No Internet? 10 Fixes to Try', href: '/wifi-internet-problems/wifi-connected-no-internet/', desc: 'Fix WiFi connected without internet access' },
    { title: 'Wi-Fi Keeps Disconnecting - How to Fix', href: '/wifi-internet-problems/wifi-keeps-disconnecting/', desc: 'Stop your WiFi from dropping connection' },
    { title: 'Slow Internet Connection - Troubleshooting Guide', href: '/wifi-internet-problems/slow-internet-connection/', desc: 'Speed up your internet connection' },
    { title: 'Router Not Working - Step by Step Fix', href: '/wifi-internet-problems/router-not-working/', desc: 'Troubleshoot router connectivity issues' },
  ]

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <nav className="text-sm text-gray-600 mb-6">
        <Link href="/" className="hover:text-brand-primary">Home</Link>
        <span className="mx-2">/</span>
        <span className="text-brand-navy">WiFi & Internet Problems</span>
      </nav>

      <header className="mb-8">
        <h1 className="text-4xl font-bold text-brand-navy mb-4">WiFi & Internet Problems</h1>
        <p className="text-lg text-gray-600">
          Fix WiFi connectivity issues, slow internet speeds, router problems, and network errors with our practical troubleshooting guides.
        </p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {articles.map((article, index) => (
          <Link
            key={index}
            href={article.href}
            className="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-lg hover:border-brand-primary transition-all duration-200 group"
          >
            <h2 className="text-xl font-semibold text-brand-navy mb-2 group-hover:text-brand-primary transition-colors">
              {article.title}
            </h2>
            <p className="text-gray-600 mb-3">{article.desc}</p>
            <div className="text-brand-primary font-medium group-hover:underline">
              Read Guide →
            </div>
          </Link>
        ))}
      </div>
    </div>
  )
}
