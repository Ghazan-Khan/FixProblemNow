import Link from 'next/link'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Sitemap - Fix Problem Now',
  description: 'Complete sitemap of all pages on Fix Problem Now.',
  alternates: {
    canonical: '/sitemap/',
  },
}

export default function SitemapPage() {
  const pages = [
    { title: 'Home', href: '/' },
    { title: 'About Us', href: '/about-us/' },
    { title: 'Contact Us', href: '/contact-us/' },
    { title: 'Editorial Policy', href: '/editorial-policy/' },
    { title: 'How We Test Solutions', href: '/how-we-test-solutions/' },
    { title: 'Privacy Policy', href: '/privacy-policy/' },
    { title: 'Terms of Use', href: '/terms-of-use/' },
    { title: 'Disclaimer', href: '/disclaimer/' },
    { title: 'Search', href: '/search/' },
  ]

  const categories = [
    { title: 'Computer Problems', href: '/computer-problems/' },
    { title: 'Phone Problems', href: '/phone-problems/' },
    { title: 'WiFi & Internet Problems', href: '/wifi-internet-problems/' },
    { title: 'Printer Problems', href: '/printer-problems/' },
    { title: 'Software Problems', href: '/software-problems/' },
    { title: 'Smart TV Problems', href: '/smart-tv-problems/' },
  ]

  const articles = [
    { title: 'Wi-Fi Connected but No Internet? 10 Fixes to Try', href: '/wifi-internet-problems/wifi-connected-no-internet/' },
    { title: 'Laptop Not Charging - Troubleshooting Guide', href: '/computer-problems/laptop-not-charging/' },
    { title: 'Printer Showing Offline - How to Fix', href: '/printer-problems/printer-showing-offline/' },
    { title: 'Smart TV Not Connecting to Wi-Fi', href: '/smart-tv-problems/tv-not-connecting-to-wifi/' },
    { title: 'Phone Not Charging - Troubleshooting Guide', href: '/phone-problems/phone-not-charging/' },
  ]

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <nav className="text-sm text-gray-600 mb-6">
        <Link href="/" className="hover:text-brand-primary">Home</Link>
        <span className="mx-2">/</span>
        <span className="text-brand-navy">Sitemap</span>
      </nav>

      <h1 className="text-4xl font-bold text-brand-navy mb-8">Sitemap</h1>

      <div className="space-y-8">
        <section>
          <h2 className="text-2xl font-bold text-brand-navy mb-4">Main Pages</h2>
          <ul className="space-y-2">
            {pages.map((page) => (
              <li key={page.href}>
                <Link href={page.href} className="text-brand-primary hover:underline">
                  {page.title}
                </Link>
              </li>
            ))}
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-brand-navy mb-4">Categories</h2>
          <ul className="space-y-2">
            {categories.map((category) => (
              <li key={category.href}>
                <Link href={category.href} className="text-brand-primary hover:underline">
                  {category.title}
                </Link>
              </li>
            ))}
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-brand-navy mb-4">Articles</h2>
          <ul className="space-y-2">
            {articles.map((article) => (
              <li key={article.href}>
                <Link href={article.href} className="text-brand-primary hover:underline">
                  {article.title}
                </Link>
              </li>
            ))}
          </ul>
        </section>
      </div>
    </div>
  )
}
