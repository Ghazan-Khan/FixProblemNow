import Link from 'next/link'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Phone Not Charging - Troubleshooting Guide | Fix Problem Now',
  description: 'Fix phone not charging issues for Android and iPhone. Check cable, charger, port, and software solutions.',
  keywords: 'phone not charging, iphone not charging, android not charging',
  alternates: {
    canonical: '/phone-problems/phone-not-charging/',
  },
}

export default function PhoneNotChargingPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <nav className="text-sm text-gray-600 mb-6">
        <Link href="/" className="hover:text-brand-primary">Home</Link>
        <span className="mx-2">/</span>
        <Link href="/phone-problems/" className="hover:text-brand-primary">Phone Problems</Link>
        <span className="mx-2">/</span>
        <span className="text-brand-navy">Phone Not Charging</span>
      </nav>

      <article>
        <header className="mb-8">
          <span className="inline-block px-3 py-1 bg-blue-100 text-brand-primary text-sm rounded-full mb-4">
            Phone Problems
          </span>
          <h1 className="text-4xl font-bold text-brand-navy mb-4">
            Phone Not Charging - Troubleshooting Guide
          </h1>
          <p className="text-lg text-gray-600">
            If your Android or iPhone won't charge, follow these step-by-step solutions to diagnose and fix the problem.
          </p>
        </header>

        <section className="mb-8">
          <h2 className="text-2xl font-bold text-brand-navy mb-4">Quick Checks</h2>
          <div className="bg-blue-50 border-l-4 border-brand-primary p-4 rounded-r-lg">
            <ol className="list-decimal pl-6 space-y-1 text-brand-navy">
              <li>Try different wall outlet</li>
              <li>Check cable for fraying or damage</li>
              <li>Try different charger and cable</li>
              <li>Inspect charging port for debris</li>
            </ol>
          </div>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-bold text-brand-navy mb-4">Step-by-Step Fixes</h2>
          
          <div className="space-y-6">
            <div className="border border-gray-200 rounded-lg p-6">
              <h3 className="text-xl font-semibold text-brand-navy mb-3">1. Clean the Charging Port</h3>
              <ul className="list-disc pl-6 space-y-2 text-gray-700">
                <li>Turn off your phone</li>
                <li>Use a flashlight to look for lint, dust, or debris</li>
                <li>Carefully clean with a dry wooden toothpick or soft brush</li>
                <li>Do NOT use metal objects, liquids, or compressed air aggressively</li>
              </ul>
            </div>

            <div className="border border-gray-200 rounded-lg p-6">
              <h3 className="text-xl font-semibold text-brand-navy mb-3">2. Try Different Charging Accessories</h3>
              <ul className="list-disc pl-6 space-y-2 text-gray-700">
                <li>Try original charger and cable if available</li>
                <li>Test with wireless charger (if supported)</li>
                <li>Try charging from computer USB port (slower)</li>
                <li>Use certified charging accessories</li>
              </ul>
            </div>

            <div className="border border-gray-200 rounded-lg p-6">
              <h3 className="text-xl font-semibold text-brand-navy mb-3">3. Force Restart Your Phone</h3>
              <p className="text-gray-700 mb-2"><strong>iPhone:</strong></p>
              <p className="text-gray-700 mb-3">Volume Up, Volume Down, then hold Side button until Apple logo</p>
              <p className="text-gray-700 mb-2"><strong>Android:</strong></p>
              <p className="text-gray-700">Hold Power button for 10-30 seconds (varies by device)</p>
            </div>

            <div className="border border-gray-200 rounded-lg p-6">
              <h3 className="text-xl font-semibold text-brand-navy mb-3">4. Check for Software Issues</h3>
              <ul className="list-disc pl-6 space-y-2 text-gray-700">
                <li>Boot in Safe Mode (Android) to check if app is interfering</li>
                <li>Update your phone's software</li>
                <li>Try charging when phone is powered off</li>
              </ul>
            </div>
          </div>
        </section>

        <section className="mb-8 bg-red-50 border-l-4 border-red-400 p-4 rounded-r-lg">
          <h2 className="text-lg font-semibold text-red-800 mb-2">⚠️ Safety Warnings</h2>
          <ul className="list-disc pl-6 space-y-1 text-red-700">
            <li>If battery is swollen, stop using and charging immediately</li>
            <li>Don't charge on soft surfaces that trap heat</li>
            <li>Use only certified chargers to avoid damage/fire risk</li>
          </ul>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-bold text-brand-navy mb-4">When to Get Help</h2>
          <ul className="list-disc pl-6 space-y-2 text-gray-700">
            <li>Phone gets extremely hot while charging</li>
            <li>Charging port is damaged or loose</li>
            <li>Battery drains instantly even after charging</li>
            <li>None of the above fixes work</li>
          </ul>
        </section>
      </article>
    </div>
  )
}
