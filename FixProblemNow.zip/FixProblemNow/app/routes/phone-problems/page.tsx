import Link from 'next/link'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Phone Problems - Troubleshooting Guides | Fix Problem Now',
  description: 'Fix Android and iPhone charging issues, battery drain, overheating, app crashes, connectivity problems with step-by-step guides.',
  keywords: 'phone problems, iphone issues, android problems, phone charging, battery drain',
  alternates: {
    canonical: '/phone-problems/',
  },
}

export default function PhoneProblemsPage() {
  const articles = [
    { title: 'Phone Not Charging - Troubleshooting Guide', href: '/phone-problems/phone-not-charging/', desc: 'Fix charging port and cable issues' },
    { title: 'Android Battery Draining Quickly', href: '/phone-problems/android-battery-draining/', desc: 'Extend battery life and fix drain' },
    { title: 'iPhone Battery Draining Quickly', href: '/phone-problems/iphone-battery-draining/', desc: 'Fix iOS battery issues' },
    { title: 'Phone Overheating - Causes and Fixes', href: '/phone-problems/phone-overheating/', desc: 'Cool down your phone safely' },
  ]

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <nav className="text-sm text-gray-600 mb-6">
        <Link href="/" className="hover:text-brand-primary">Home</Link>
        <span className="mx-2">/</span>
        <span className="text-brand-navy">Phone Problems</span>
      </nav>

      <header className="mb-8">
        <h1 className="text-4xl font-bold text-brand-navy mb-4">Phone Problems</h1>
        <p className="text-lg text-gray-600">
          Troubleshoot Android and iPhone issues including charging, battery, performance, connectivity, and app problems.
        </p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {articles.map((article, index) => (
          <Link
            key={index}
            href={article.href}
            className="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-lg hover:border-brand-primary transition-all duration-200 group"
          >
            <h2 className="text-xl font-semibold text-brand-navy mb-2 group-hover:text-brand-primary transition-colors">
              {article.title}
            </h2>
            <p className="text-gray-600 mb-3">{article.desc}</p>
            <div className="text-brand-primary font-medium group-hover:underline">
              Read Guide →
            </div>
          </Link>
        ))}
      </div>
    </div>
  )
}
