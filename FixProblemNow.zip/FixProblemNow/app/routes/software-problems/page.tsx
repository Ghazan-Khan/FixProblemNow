import Link from 'next/link'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Software Problems - Troubleshooting Guides | Fix Problem Now',
  description: 'Fix app crashes, software installation errors, program not opening, update failures, compatibility issues with step-by-step guides.',
  keywords: 'software problems, app crashes, program not responding, installation errors',
  alternates: {
    canonical: '/software-problems/',
  },
}

export default function SoftwareProblemsPage() {
  const articles = [
    { title: 'Application Keeps Crashing - How to Fix', href: '/software-problems/application-keeps-crashing/', desc: 'Fix crashing apps and programs' },
    { title: 'Software Installation Failed - Troubleshooting', href: '/software-problems/software-installation-failed/', desc: 'Resolve installation errors' },
    { title: 'Program Not Responding - Fix Guide', href: '/software-problems/program-not-responding/', desc: 'Fix frozen applications' },
    { title: 'Browser Running Slowly - Speed Up Guide', href: '/software-problems/browser-running-slowly/', desc: 'Improve browser performance' },
  ]

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <nav className="text-sm text-gray-600 mb-6">
        <Link href="/" className="hover:text-brand-primary">Home</Link>
        <span className="mx-2">/</span>
        <span className="text-brand-navy">Software Problems</span>
      </nav>

      <header className="mb-8">
        <h1 className="text-4xl font-bold text-brand-navy mb-4">Software Problems</h1>
        <p className="text-lg text-gray-600">
          Troubleshoot application crashes, installation errors, performance issues, and software compatibility problems.
        </p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {articles.map((article, index) => (
          <Link
            key={index}
            href={article.href}
            className="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-lg hover:border-brand-primary transition-all duration-200 group"
          >
            <h2 className="text-xl font-semibold text-brand-navy mb-2 group-hover:text-brand-primary transition-colors">
              {article.title}
            </h2>
            <p className="text-gray-600 mb-3">{article.desc}</p>
            <div className="text-brand-primary font-medium group-hover:underline">
              Read Guide →
            </div>
          </Link>
        ))}
      </div>
    </div>
  )
}
