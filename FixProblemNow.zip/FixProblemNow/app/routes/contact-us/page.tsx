import Link from 'next/link'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Contact Us - Fix Problem Now',
  description: 'Get in touch with Fix Problem Now. Send us your questions, feedback, or suggestions about our troubleshooting guides.',
  alternates: {
    canonical: '/contact-us/',
  },
}

export default function ContactUsPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <nav className="text-sm text-gray-600 mb-6">
        <Link href="/" className="hover:text-brand-primary">Home</Link>
        <span className="mx-2">/</span>
        <span className="text-brand-navy">Contact Us</span>
      </nav>

      <h1 className="text-4xl font-bold text-brand-navy mb-6">Contact Us</h1>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div>
          <p className="text-gray-700 mb-6">
            Have a question, feedback, or suggestion about our troubleshooting guides? 
            We'd love to hear from you. Send us a message and we'll get back to you as soon as possible.
          </p>

          <div className="bg-blue-50 border-l-4 border-brand-primary p-4 rounded-r-lg">
            <p className="text-brand-navy text-sm">
              <strong>Note:</strong> We provide general troubleshooting guidance only. 
              For urgent technical issues, please contact your device manufacturer or qualified technician.
            </p>
          </div>
        </div>

        <div>
          <form className="space-y-4">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                Name
              </label>
              <input
                type="text"
                id="name"
                name="name"
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary"
              />
            </div>

            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                Email
              </label>
              <input
                type="email"
                id="email"
                name="email"
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary"
              />
            </div>

            <div>
              <label htmlFor="subject" className="block text-sm font-medium text-gray-700 mb-1">
                Subject
              </label>
              <input
                type="text"
                id="subject"
                name="subject"
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary"
              />
            </div>

            <div>
              <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">
                Message
              </label>
              <textarea
                id="message"
                name="message"
                rows={5}
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary"
              ></textarea>
            </div>

            <button
              type="submit"
              className="w-full px-4 py-2 bg-brand-primary text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              Send Message
            </button>
          </form>
          <p className="text-xs text-gray-500 mt-2">
            * Form is for demonstration purposes. Email delivery needs to be configured.
          </p>
        </div>
      </div>
    </div>
  )
}
