import Link from 'next/link'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'About Us - Fix Problem Now',
  description: 'Learn about Fix Problem Now - our mission to help people solve everyday technology problems with simple, step-by-step guides.',
  alternates: {
    canonical: '/about-us/',
  },
}

export default function AboutUsPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <nav className="text-sm text-gray-600 mb-6">
        <Link href="/" className="hover:text-brand-primary">Home</Link>
        <span className="mx-2">/</span>
        <span className="text-brand-navy">About Us</span>
      </nav>

      <h1 className="text-4xl font-bold text-brand-navy mb-6">About Fix Problem Now</h1>

      <div className="prose prose-lg max-w-none">
        <section className="mb-8">
          <h2 className="text-2xl font-bold text-brand-navy mb-4">Our Mission</h2>
          <p className="text-gray-700 mb-4">
            Fix Problem Now helps people understand and solve common technology problems without unnecessary technical jargon. 
            Our goal is to make technology troubleshooting accessible to everyone, from beginners to experienced users.
          </p>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-bold text-brand-navy mb-4">What We Do</h2>
          <p className="text-gray-700 mb-4">
            We provide practical, step-by-step troubleshooting guides that help you:
          </p>
          <ul className="list-disc pl-6 space-y-2 text-gray-700 mb-4">
            <li>Identify the likely cause of technology problems</li>
            <li>Start with the simplest and safest solutions</li>
            <li>Follow clear, numbered instructions</li>
            <li>Try alternative fixes if the first solution doesn't work</li>
            <li>Know when professional help is needed</li>
          </ul>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-bold text-brand-navy mb-4">Our Approach</h2>
          <p className="text-gray-700 mb-4">
            Every guide is written with the user in mind - clear language, logical steps, and safety considerations. 
            We focus on practical solutions you can try at home without expensive tools or technical expertise.
          </p>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-bold text-brand-navy mb-4">Audience</h2>
          <p className="text-gray-700">
            We serve global users including beginners, students, professionals, home users, remote workers, 
            small businesses, and anyone looking for practical solutions to everyday technology problems.
          </p>
        </section>
      </div>
    </div>
  )
}
