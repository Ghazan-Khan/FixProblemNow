import Link from 'next/link'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Terms of Use - Fix Problem Now',
  description: 'Terms of Use for Fix Problem Now website.',
  alternates: {
    canonical: '/terms-of-use/',
  },
}

export default function TermsOfUsePage() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <nav className="text-sm text-gray-600 mb-6">
        <Link href="/" className="hover:text-brand-primary">Home</Link>
        <span className="mx-2">/</span>
        <span className="text-brand-navy">Terms of Use</span>
      </nav>

      <h1 className="text-4xl font-bold text-brand-navy mb-6">Terms of Use</h1>
      <p className="text-gray-600 mb-6">Last updated: October 21, 2026</p>

      <div className="prose prose-lg max-w-none space-y-6">
        <section>
          <h2 className="text-2xl font-bold text-brand-navy mb-3">Acceptance of Terms</h2>
          <p className="text-gray-700">
            By accessing and using Fix Problem Now, you accept and agree to be bound by the terms and provision of this agreement.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-brand-navy mb-3">Use License</h2>
          <p className="text-gray-700">
            Permission is granted to temporarily view the materials on Fix Problem Now for personal, non-commercial transitory viewing only.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-brand-navy mb-3">Disclaimer</h2>
          <p className="text-gray-700">
            The materials on Fix Problem Now are provided on an 'as is' basis. Fix Problem Now makes no warranties, expressed or implied.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-brand-navy mb-3">Limitations</h2>
          <p className="text-gray-700">
            In no event shall Fix Problem Now or its suppliers be liable for any damages arising out of the use or inability to use the materials.
          </p>
        </section>
      </div>
    </div>
  )
}
