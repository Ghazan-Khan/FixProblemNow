'use client'

import Link from 'next/link'
import { useSearchParams } from 'next/navigation'
import { Suspense } from 'react'

const allArticles = [
  { title: 'Wi-Fi Connected but No Internet? 10 Fixes to Try', href: '/wifi-internet-problems/wifi-connected-no-internet/', category: 'WiFi & Internet', keywords: ['wifi', 'internet', 'connected', 'no internet'] },
  { title: 'Laptop Not Charging - Troubleshooting Guide', href: '/computer-problems/laptop-not-charging/', category: 'Computer Problems', keywords: ['laptop', 'charging', 'battery', 'not charging'] },
  { title: 'Printer Showing Offline - How to Fix', href: '/printer-problems/printer-showing-offline/', category: 'Printer Problems', keywords: ['printer', 'offline', 'not printing'] },
  { title: 'Smart TV Not Connecting to Wi-Fi', href: '/smart-tv-problems/tv-not-connecting-to-wifi/', category: 'Smart TV Problems', keywords: ['tv', 'wifi', 'smart tv', 'connect'] },
  { title: 'Phone Not Charging - Troubleshooting Guide', href: '/phone-problems/phone-not-charging/', category: 'Phone Problems', keywords: ['phone', 'charging', 'iphone', 'android'] },
]

function SearchResults() {
  const searchParams = useSearchParams()
  const query = searchParams.get('q')?.toLowerCase() || ''

  const results = query
    ? allArticles.filter(article =>
        article.title.toLowerCase().includes(query) ||
        article.category.toLowerCase().includes(query) ||
        article.keywords.some(keyword => keyword.includes(query))
      )
    : []

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <nav className="text-sm text-gray-600 mb-6">
        <Link href="/" className="hover:text-brand-primary">Home</Link>
        <span className="mx-2">/</span>
        <span className="text-brand-navy">Search</span>
      </nav>

      <h1 className="text-3xl font-bold text-brand-navy mb-6">Search Results</h1>

      <form action="/search/" method="get" className="mb-8">
        <div className="flex gap-3">
          <input
            type="text"
            name="q"
            defaultValue={query}
            placeholder="Search for problems..."
            className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary"
          />
          <button
            type="submit"
            className="px-6 py-2 bg-brand-primary text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            Search
          </button>
        </div>
      </form>

      {query && (
        <p className="text-gray-600 mb-6">
          {results.length} result{results.length !== 1 ? 's' : ''} for "{query}"
        </p>
      )}

      {query && results.length > 0 && (
        <div className="space-y-4">
          {results.map((result, index) => (
            <Link
              key={index}
              href={result.href}
              className="block bg-white border border-gray-200 rounded-lg p-6 hover:shadow-md hover:border-brand-primary transition-all"
            >
              <span className="inline-block px-2 py-1 bg-blue-100 text-brand-primary text-xs rounded-full mb-2">
                {result.category}
              </span>
              <h2 className="text-lg font-semibold text-brand-navy mb-2 hover:text-brand-primary">
                {result.title}
              </h2>
              <div className="text-brand-primary text-sm">Read Guide →</div>
            </Link>
          ))}
        </div>
      )}

      {query && results.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-600 mb-4">No results found for "{query}"</p>
          <p className="text-gray-500">Try searching for: wifi, printer, laptop, phone, or router</p>
        </div>
      )}

      {!query && (
        <div className="text-center py-12">
          <p className="text-gray-600">Enter a search term to find troubleshooting guides</p>
        </div>
      )}
    </div>
  )
}

export default function SearchPage() {
  return (
    <Suspense fallback={<div className="max-w-4xl mx-auto px-4 py-8">Loading...</div>}>
      <SearchResults />
    </Suspense>
  )
}
